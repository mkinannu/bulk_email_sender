import os
import base64
from email.mime.text import MIMEText
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Gmail API scope for sending email
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

# File paths
CREDENTIALS_FILE = 'credentials.json'
TOKEN_FILE = 'token.json'

def authenticate():
    creds = None

    # Load existing token if available
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)

    # If no valid credentials, start interactive auth
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)

        # Save the token for future use
        with open(TOKEN_FILE, 'w') as token:
            token.write(creds.to_json())

    return creds

def create_message(sender, to, subject, message_text):
    message = MIMEText(message_text)
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject
    raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {'raw': raw}

def send_email():
    creds = authenticate()
    service = build('gmail', 'v1', credentials=creds)

    message = create_message(
        sender='your-email@gmail.com',
        to='recipient@gmail.com',
        subject='Hello from Gmail API',
        message_text='This is a test email using cached credentials!'
    )

    sent = service.users().messages().send(userId="me", body=message).execute()
    print(f'Email sent! Message ID: {sent["id"]}')

if __name__ == '__main__':
    send_email()
