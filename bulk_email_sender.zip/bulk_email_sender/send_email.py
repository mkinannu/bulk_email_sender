from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from email.mime.text import MIMEText
import base64

# Authentication
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

creds = Credentials.from_authorized_user_file('credentials.json', SCOPES)
service = build('gmail', 'v1', credentials=creds)

# Create email
def create_message(sender, to, subject, message_text):
    message = MIMEText(message_text)
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject
    return {'raw': base64.urlsafe_b64encode(message.as_bytes()).decode()}

# Send email
message = create_message(
    sender='me',
    to='mdnannu04@gmail.com',
    subject='Test Email  1',
    message_text='This is a test email sent via Gmail API'
)
service.users().messages().send(userId='me', body=message).execute()