# from flask import Flask, request, jsonify, send_from_directory
# import os
# from datetime import datetime
# from weasyprint import HTML

# app = Flask(__name__)
# SAVE_FOLDER = "pdfs"
# os.makedirs(SAVE_FOLDER, exist_ok=True)

# @app.route('/')
# def index():
#     return send_from_directory('.', 'html2pdf.html')

# @app.route('/convert', methods=['POST'])
# def convert_html_to_pdf():
#     data = request.get_json()
#     html_content = data.get("html", "")
#     timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
#     filename = f"output_{timestamp}.pdf"
#     filepath = os.path.join(SAVE_FOLDER, filename)

#     # Save PDF
#     HTML(string=html_content).write_pdf(filepath)

#     return jsonify({
#         "path": filename,
#         "url": f"/pdfs/{filename}"
#     })

# @app.route('/pdfs/<filename>')
# def serve_pdf(filename):
#     return send_from_directory(SAVE_FOLDER, filename)

# if __name__ == '__main__':
#     app.run(debug=True)

# import asyncio
# from pyppeteer import launch
# async def generate_pdf_from_html(html_content, pdf_path):
#     browser = await launch()
#     page = await browser.newPage()
    
#     await page.setContent(html_content)
    
#     await page.pdf({'path': pdf_path, 'format': 'A4'})
    
#     await browser.close()

# # HTML content
# html_content = '''
# <!DOCTYPE html>
# <html>
# <head>
#     <title>PDF Example</title>
# </head>
# <body>
#     <h1>Hello, world!</h1>
# </body>
# </html>
# '''

# # Run the function
# asyncio.get_event_loop().run_until_complete(generate_pdf_from_html(html_content, 'from_html.pdf'))


# from xhtml2pdf import pisa

# def convert_html_to_pdf(html_string, pdf_path):
#     with open(pdf_path, "wb") as pdf_file:
#         pisa_status = pisa.CreatePDF(html_string, dest=pdf_file)
        
#     return not pisa_status.err

# # HTML content
# # html_content = '''
# # <!DOCTYPE html>
# # <html>
# # <head>
# #     <title>PDF Example</title>
# # </head>
# # <body>
# #     <h1>Hello, world!</h1>
# # </body>
# # </html>
# # '''

# # Generate PDF
# # pdf_path = "example.pdf"
# if convert_html_to_pdf(html_content, pdf_path):
#     print(f"PDF generated and saved at {pdf_path}")
# else:
#     print("PDF generation failed")


# import asyncio
# from playwright.async_api import async_playwright

# async def html_to_pdf(html_content, output_path):
#     async with async_playwright() as p:
#         browser = await p.chromium.launch()
#         page = await browser.new_page()
#         await page.set_content(html_content)
#         await page.pdf(path=output_path)
#         await browser.close()

# html_content = '''
# <!DOCTYPE html>
# <html lang="en">
# <head>
#     <meta charset="UTF-8">
#     <meta name="viewport" content="width=device-width, initial-scale=1.0">
#     <title>Sample HTML</title>
# </head>
# <body>
#     <h1>Hello, World!</h1>
#     <p>This is a sample HTML content to be converted to PDF.</p>
# </body>
# </html>
# '''
# output_path = 'cust.pdf'

# asyncio.run(html_to_pdf(html_content, output_path))



# from weasyprint import HTML

# def html_to_pdf(html_content, output_path):
#     HTML(string=html_content).write_pdf(output_path)

# html_content = '''
# <!DOCTYPE html>
# <html lang="en">
# <head>
#     <meta charset="UTF-8">
#     <meta name="viewport" content="width=device-width, initial-scale=1.0">
#     <title>Sample HTML</title>
# </head>
# <body>
#     <h1>Hello, World!</h1>
#     <p>This is a sample HTML content to be converted to PDF.</p>
# </body>
# </html>
# '''
# output_path = 'output_html.pdf'

# html_to_pdf(html_content, output_path)






import pdfkit 
pdfkit.from_file('test.html', 'out.pdf') 