import os
import pickle
import base64
import mimetypes
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from flask import Flask, request, render_template_string
from werkzeug.utils import secure_filename

# Gmail API scope
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

# Flask app setup
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# OAuth2 Authentication
def authenticate():
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    
    return creds

# Create Gmail message with HTML and attachments support
def create_message(sender, to, subject, message_text, message_html=None, attachments=None):
    print(to)
    if message_html:
        message = MIMEMultipart('alternative')
    else:
        message = MIMEMultipart()
    
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject
    
    # Add both plain text and HTML versions
    message.attach(MIMEText(message_text, 'plain'))
    if message_html:
        message.attach(MIMEText(message_html, 'html'))

    # Handle multiple attachments
    if attachments:
        for attachment in attachments:
            if not os.path.exists(attachment):
                continue
                
            content_type, encoding = mimetypes.guess_type(attachment)
            if content_type is None or encoding is not None:
                content_type = 'application/octet-stream'
            main_type, sub_type = content_type.split('/', 1)

            with open(attachment, 'rb') as file:
                file_data = file.read()
                msg_attachment = MIMEBase(main_type, sub_type)
                msg_attachment.set_payload(file_data)
                encoders.encode_base64(msg_attachment)
                msg_attachment.add_header(
                    'Content-Disposition',
                    f'attachment; filename="{os.path.basename(attachment)}"'
                )
                message.attach(msg_attachment)

    raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {'raw': raw_message}

# Send Gmail message
def send_message(service, sender, to, subject, message_text, message_html=None, attachments=None):
    message = create_message(sender, to, subject, message_text, message_html, attachments)
    try:
        result = service.users().messages().send(userId="me", body=message).execute()
        return f'Email sent successfully! Message ID: {result["id"]}'
    except Exception as error:
        return f'An error occurred: {error}'

# HTML Template with styling and multiple file upload
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Gmail API Email Sender</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #4285F4;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }
        input[type="text"],
        input[type="email"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        textarea {
            min-height: 100px;
            resize: vertical;
        }
        #html_content {
            min-height: 200px;
            font-family: monospace;
        }
        .file-upload {
            background: #f9f9f9;
            padding: 15px;
            border: 1px dashed #ccc;
            border-radius: 4px;
            text-align: center;
        }
        button {
            background-color: #4285F4;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #3367D6;
        }
        .tab {
            display: none;
        }
        .tab-button {
            background: #eee;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        .tab-button.active {
            background: #4285F4;
            color: white;
        }
        .response {
            margin-top: 20px;
            padding: 15px;
            border-radius: 4px;
        }
        .success {
            background-color: #E6F4EA;
            color: #0D652D;
        }
        .error {
            background-color: #FCE8E6;
            color: #D93025;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
</head>
<body>
    <div class="container">
        <h1>Send Email via Gmail API</h1>
        
        {% if response %}
        <div class="response {% if 'successfully' in response %}success{% else %}error{% endif %}">
            {{ response }}
        </div>
        {% endif %}
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="to">Recipient Email:</label>
                <input type="text" id="to" name="to" required>
            </div>
            
            <div class="form-group">
                <label for="subject">Subject:</label>
                <input type="text" id="subject" name="subject" required value="Purchase Notification">
            </div>
            
            <div class="form-group">
                <label for="message">Plain Text Message:</label>
                <textarea id="message" name="message" required>Please Check this mail</textarea>
            </div>
            
            <div class="form-group">
                <label for="html_content">HTML Message (optional):</label>
                <textarea id="html_content" name="html_content" placeholder="<html><body><h1>Your HTML here</h1></body></html>">
                
                </textarea>
            </div>
            
            <div class="form-group">
                <label>Attachments (multiple allowed):</label>
                <div class="file-upload">
                    <input type="file" name="attachments" multiple>
                </div>
            </div>
            
            <button type="submit">Send Email</button>
        </form>
    </div>
</body>
<script>
var mail=`ajaygoel999@gmail.com,test@chromecompete.com,test@ajaygoel.org,me@dropboxslideshow.com,test@wordzen.com,rajgoel8477@gmail.com,rajanderson8477@gmail.com,rajwilson8477@gmail.com,briansmith8477@gmail.com,oliviasmith8477@gmail.com,ashsmith8477@gmail.com,shellysmith8477@gmail.com,ajay@madsciencekidz.com,ajay2@ctopowered.com,ajay@arena.tec.br,ajay@daustin.co`
 document.getElementById('to').value=mail
   function renderHTML() {
    const rawHTML = document.getElementById("htmlInput").value;
    const cleanHTML = DOMPurify.sanitize(rawHTML);
    document.getElementById("rendered-content").innerHTML = cleanHTML;
  }

  function downloadPDF() {
    const content = document.getElementById("rendered-content");
    html2pdf().from(content).save();
  }
</script>
</html>
"""

# Flask route
@app.route('/', methods=['GET', 'POST'])
def index():
    response = None
    
    if request.method == 'POST':
        # Get form data
        sender = 'me'
        to = request.form['to']
        subject = request.form['subject']
        message_text = request.form['message']
        message_html = request.form.get('html_content')
        
        # Handle file uploads
        attachment_paths = []
        if 'attachments' in request.files:
            for file in request.files.getlist('attachments'):
                if file.filename != '':
                    filename = secure_filename(file.filename)
                    if not os.path.exists(app.config['UPLOAD_FOLDER']):
                        os.makedirs(app.config['UPLOAD_FOLDER'])
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(filepath)
                    attachment_paths.append(filepath)
        
        try:
            # Authenticate and send email
            creds = authenticate()
            service = build('gmail', 'v1', credentials=creds)
            response = send_message(
                service, 
                sender, 
                to, 
                subject, 
                message_text, 
                message_html, 
                attachment_paths
            )
        except Exception as e:
            response = f"Error: {str(e)}"
        finally:
            # Clean up uploaded files
            for path in attachment_paths:
                if os.path.exists(path):
                    os.remove(path)
    
    return render_template_string(HTML_TEMPLATE, response=response)

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)