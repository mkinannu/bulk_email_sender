import os
import base64
import mimetypes
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from werkzeug.utils import secure_filename
from email.message import EmailMessage
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from xhtml2pdf import pisa
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


UPLOAD_FOLDER = "static/uploads"
ALLOWED_EXTENSIONS = {"txt", "pdf", "png", "jpg", "jpeg", "gif"}

SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

app = Flask(__name__)
app.secret_key = "secret"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def authenticate():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    else:
        flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
        creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)


# def create_message_advanced(sender, to, subject, message_text, html_text, cc=None, bcc=None, attachments=None, inline_images=None):
#     message = EmailMessage()
#     message["To"] = to
#     message["From"] = sender
#     message["Subject"] = subject
#     if cc:
#         message["Cc"] = cc
#     if bcc:
#         message["Bcc"] = bcc

#     message.set_content(message_text)
#     if html_text:
#         message.add_alternative(html_text, subtype="html")
       

#     if inline_images:
#         for cid, path in inline_images.items():
#             with open(path, "rb") as img:
#                 data = img.read()
#                 maintype, subtype = mimetypes.guess_type(path)[0].split("/")
#                 message.get_payload()[-1].add_related(data, maintype=maintype, subtype=subtype, cid=f"<{cid}>")

#     if attachments:
#         for file_path in attachments:
#             mime_type, _ = mimetypes.guess_type(file_path)
#             if not mime_type:
#                 mime_type = "application/octet-stream"
#             maintype, subtype = mime_type.split("/", 1)
#             with open(file_path, "rb") as f:
#                 data = f.read()
#             message.add_attachment(data, maintype, subtype, filename=os.path.basename(file_path))

#     return {"raw": base64.urlsafe_b64encode(message.as_bytes()).decode()}

# def convert_html_to_pdf(html_string, pdf_path):
#     with open(pdf_path, "wb") as pdf_file:
#         pisa_status = pisa.CreatePDF(html_string, dest=pdf_file)
        
    return not pisa_status.err
def create_message_advanced(sender, to, subject, message_text, html_text=None, cc=None, bcc=None, attachments=None, inline_images=None):
    """Create a MIME message for sending"""
    message = MIMEMultipart('mixed' if attachments or inline_images else 'alternative')
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject

    if cc:
        message['cc'] = cc
    if bcc:
        message['bcc'] = bcc

    # Plain text part
    if message_text:
        message.attach(MIMEText(message_text, 'plain'))

    # HTML part
    if html_text:
        message.attach(MIMEText(html_text, 'html'))

    # Handle attachments
    if attachments:
        for filepath in attachments:
            with open(filepath, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment', filename=os.path.basename(filepath))
                message.attach(part)

    # Handle inline images
    if inline_images:
        for cid, filepath in inline_images.items():
            with open(filepath, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'inline', filename=os.path.basename(filepath))
                part.add_header('Content-ID', f'<{cid}>')
                message.attach(part)

    raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {'raw': raw_message}
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        to = request.form["to"]
        cc = request.form.get("cc", "")
        bcc = request.form.get("bcc", "")
        subject = request.form["subject"]
        body = request.form["body"]
        html = request.form.get("html", "")
        attachments = []
        inline_images = {}

        files = request.files.getlist("attachments")
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                file.save(path)
                if "cid:" in body + html:
                    cid = filename.split(".")[0]
                    inline_images[cid] = path
                else:
                    attachments.append(path)

        try:
            service = authenticate()
            msg = create_message_advanced(
                sender="me",
                to=to,
                subject=subject,
                message_text=body,
                html_text=html,
                cc=cc,
                bcc=bcc,
                attachments=attachments,
                inline_images=inline_images
            )
            service.users().messages().send(userId="me", body=msg).execute()
            flash("✅ Email sent successfully!", "success")
        except Exception as e:
            flash(f"❌ Failed to send email: {e}", "danger")

        return redirect(url_for("index"))

    # return render_template("index_v2.html")
    # return render_template("index_v2_1.html")
    # return render_template("index_v2_2.html")#--working
    # return render_template("index_v2_3.html")
    return render_template("index_v2_4.html")


@app.route("/send_email", methods=["POST"])
def send_mail():
    if request.method == "POST":
        # Get data from JSON payload
        data = request.get_json()
        if not data:
            return jsonify({"success": False, "message": "No JSON data received"}), 400

        try:
            # Extract email data from the new structure
            email_data = data.get("emailData", {})
            attachments_data = data.get("attachments", [])
            
            to = email_data.get("to", "")
            cc = email_data.get("cc", "")
            bcc = email_data.get("bcc", "")
            subject = email_data.get("subject", "")
            body = email_data.get("body", "")
            
            print(f"Preparing to send email to: {to}")
            print(f"Number of attachments: {len(attachments_data)}")

            # Process attachments
            attachments = []
            inline_images = {}
            
            for attachment in attachments_data:
                try:
                    # Use the correct field names from the frontend
                    file_content = base64.b64decode(attachment["content"])
                    filename = secure_filename(attachment["filename"])
                    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                    
                    # Save the file
                    with open(path, "wb") as f:
                        f.write(file_content)
                    
                    # Check if it's an inline image
                    if "cid:" in body:
                        cid = filename.split(".")[0]
                        inline_images[cid] = path
                    else:
                        attachments.append(path)
                except Exception as e:
                    print(f"Error processing attachment {attachment.get('filename')}: {str(e)}")
                    continue

            # Send email using your service
            service = authenticate()
            msg = create_message_advanced(
                sender="me",
                to=to,
                subject=subject,
                message_text=body,
                html_text=email_data.get("html", ""),  # Added HTML support
                cc=cc,
                bcc=bcc,
                attachments=attachments,
                inline_images=inline_images
            )
            
            # Execute the send
            result = service.users().messages().send(userId="me", body=msg).execute()
            print(f"Email sent successfully: {result}")
            
            # Clean up attachments
            for path in attachments + list(inline_images.values()):
                try:
                    os.remove(path)
                except Exception as e:
                    print(f"Error deleting attachment {path}: {str(e)}")
            
            return jsonify({
                "success": True,
                "message": "Email sent successfully",
                "email_id": result.get("id", "")
            }), 200
            
        except Exception as e:
            print(f"Error sending email: {str(e)}", exc_info=True)
            return jsonify({
                "success": False,
                "message": f"Failed to send email: {str(e)}"
            }), 500 

if __name__ == "__main__":
    app.run(debug=True)
