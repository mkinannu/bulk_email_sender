import os
import pickle
import base64
import mimetypes
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from flask import Flask, request, render_template_string, redirect, url_for
from werkzeug.utils import secure_filename

# Gmail API scope
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

# Flask app setup
app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Authenticate with Gmail API
def authenticate():
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists('credentials.json'):
                raise FileNotFoundError("Missing 'credentials.json'")
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return creds

# Create Gmail message
def create_message(sender, to, subject, message_text, attachment=None):
    message = MIMEMultipart()
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject
    message.attach(MIMEText(message_text, 'plain'))

    if attachment:
        content_type, encoding = mimetypes.guess_type(attachment)
        if content_type is None or encoding is not None:
            content_type = 'application/octet-stream'
        main_type, sub_type = content_type.split('/', 1)

        with open(attachment, 'rb') as file:
            file_data = file.read()
            msg_attachment = MIMEBase(main_type, sub_type)
            msg_attachment.set_payload(file_data)
            encoders.encode_base64(msg_attachment)
            msg_attachment.add_header('Content-Disposition', f'attachment; filename="{os.path.basename(attachment)}"')
            message.attach(msg_attachment)

    raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {'raw': raw_message}

# Send Gmail message
def send_message(service, sender, to, subject, message_text, attachment=None):
    message = create_message(sender, to, subject, message_text, attachment)
    try:
        result = service.users().messages().send(userId="me", body=message).execute()
        return f'✅ Email sent successfully! Message ID: {result["id"]}'
    except Exception as error:
        return f'❌ Error sending email: {error}'

# Main route
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get form data
        to = request.form.get('to')
        subject = request.form.get('subject')
        message_text = request.form.get('message')
        attachment_file = request.files.get('attachment')
        credentials_file = request.files.get('json')

        # Save credentials.json if uploaded
        if credentials_file and credentials_file.filename.endswith('.json'):
            credentials_path = os.path.join(UPLOAD_FOLDER, secure_filename(credentials_file.filename))
            credentials_file.save(credentials_path)
            os.replace(credentials_path, 'credentials.json')

        # Save attachment if exists
        attachment_path = None
        if attachment_file and attachment_file.filename:
            attachment_path = os.path.join(UPLOAD_FOLDER, secure_filename(attachment_file.filename))
            attachment_file.save(attachment_path)

        try:
            creds = authenticate()
            service = build('gmail', 'v1', credentials=creds)
            result = send_message(service, 'me', to, subject, message_text, attachment_path)
        except Exception as e:
            result = str(e)

        # Cleanup files
        if attachment_path and os.path.exists(attachment_path):
            os.remove(attachment_path)

        return result

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Send Gmail with Attachment</title>
        <style>
            body {
                font-family: Arial;
                background: #f0f0f0;
                padding: 30px;
            }
            .container {
                max-width: 600px;
                margin: auto;
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            h2 {
                color: #4CAF50;
                text-align: center;
            }
            label {
                display: block;
                margin-top: 15px;
                font-weight: bold;
            }
            input, textarea {
                width: 100%;
                padding: 10px;
                margin-top: 5px;
                box-sizing: border-box;
            }
            button {
                margin-top: 20px;
                padding: 10px;
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                width: 100%;
                font-size: 16px;
                cursor: pointer;
            }
            button:hover {
                background-color: #45a049;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Send Email via Gmail API</h2>
            <form method="POST" enctype="multipart/form-data">
                <label>Upload credentials.json</label>
                <input type="file" name="json" accept=".json" required>

                <label>To</label>
                <input type="email" name="to" required>

                <label>Subject</label>
                <input type="text" name="subject" required>

                <label>Message</label>
                <textarea name="message" required></textarea>

                <label>Attachment (optional)</label>
                <input type="file" name="attachment">

                <button type="submit">Send Email</button>
            </form>
        </div>
    </body>
    </html>
    """)

if __name__ == '__main__':
    app.run(debug=True)
