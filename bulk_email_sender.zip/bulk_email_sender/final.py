from __future__ import print_function
import os.path
import base64
import pickle
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.send']

def get_gmail_service():
    print("🔐 Checking credentials...")
    creds = None

    if os.path.exists('token.pickle'):
        print("📁 Found existing token.pickle, loading...")
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            print("♻️ Refreshing expired token...")
            creds.refresh(Request())
        else:
            print("🧭 Launching auth flow from credentials.json...")
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
            print("✅ New token saved to token.pickle")

    print("✅ Gmail service ready.")
    return build('gmail', 'v1', credentials=creds)

def create_message_with_attachment(sender, to, subject, message_text, file_path):
    print("✉️ Creating message...")
    message = MIMEMultipart()
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject

    message.attach(MIMEText(message_text, 'plain'))
    print("📝 Body attached.")

    try:
        with open(file_path, 'rb') as f:
            file_data = f.read()
            filename = os.path.basename(file_path)

        print(f"📎 Attaching file: {filename}")
        mime_part = MIMEBase('application', 'octet-stream')
        mime_part.set_payload(file_data)
        encoders.encode_base64(mime_part)
        mime_part.add_header('Content-Disposition', 'attachment', filename=filename)
        message.attach(mime_part)

        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
        print("📤 Message prepared (base64 encoded).")
        return {'raw': raw_message}
    except Exception as e:
        print(f"❌ Error while attaching file: {e}")
        raise

def send_email_with_attachment():
    try:
        print("🚀 Starting email send process...")
        service = get_gmail_service()

        message = create_message_with_attachment(
            sender='oneprojectdev@gmail.com',
            to='mdnannu04@gmail.com,shahin019177@gmail.com',
            subject='Test Email with Attachment',
            message_text='This email contains an attachment.',
            file_path='MKI.pdf'  # <-- Update this!
        )

        print("📨 Sending email...")
        sent = service.users().messages().send(userId='me', body=message).execute()
        print('✅ Email sent successfully!')
        print('📬 Message ID:', sent['id'])

    except Exception as e:
        print(f"🔥 Email send failed: {e}")

# Run the process
send_email_with_attachment()
