import base64
from email.mime.text import MIMEText
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from tkinter import Tk, filedialog

# Hide the root tkinter window
Tk().withdraw()

# Let user select credentials.json
json_path = filedialog.askopenfilename(title="Select Google API credentials JSON", filetypes=[("JSON files", "*.json")])

# Define the scope
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

# Authorize
flow = InstalledAppFlow.from_client_secrets_file(json_path, SCOPES)
creds = flow.run_local_server(port=0)

# Build Gmail service
service = build('gmail', 'v1', credentials=creds)

# Create and send message
def create_message(sender, to, subject, message_text):
    message = MIMEText(message_text)
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject
    raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {'raw': raw}

message = create_message('your-email@gmail.com', 'recipient@gmail.com', 'Hello', 'This is a test email.')
send_message = service.users().messages().send(userId="me", body=message).execute()
print(f"Message sent! ID: {send_message['id']}")
