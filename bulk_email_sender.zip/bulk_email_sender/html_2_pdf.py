import pdfkit
from pdfkit.configuration import Configuration

# Specify the path to the wkhtmltopdf executable
path_to_wkhtmltopdf = r'D:\bulk_email_sender\wkhtmltopdf\wkhtmltopdf.exe'  # Replace with your actual path

config = Configuration(wkhtmltopdf=path_to_wkhtmltopdf)

try:
    pdfkit.from_file('input.html', 'output.pdf', configuration=config)
    print("HTML to PDF conversion successful!")
except OSError as e:
    print(f"Error during PDF conversion: {e}")