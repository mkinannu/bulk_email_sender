from flask import Flask, render_template, session, redirect, url_for
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
import os
import json
from pathlib import Path

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Needed for session management

# Get the directory where app.py is located
BASE_DIR = Path(__file__).parent

# Path to client_secret.json in the same directory as app.py
CLIENT_SECRET_FILE = BASE_DIR / 'client_secret.json'

# Load client secret data
with open(CLIENT_SECRET_FILE) as f:
    client_secret_data = json.load(f)

# Google OAuth configuration
GOOGLE_CLIENT_ID = client_secret_data['web']['client_id']
GOOGLE_CLIENT_SECRET = client_secret_data['web']['client_secret']
REDIRECT_URI = 'http://localhost:5000/callback'  # Update this in your Google Cloud Console too

# Scopes for Gmail API
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

@app.route('/')
def index():
    # Check if user is already authenticated
    if 'credentials' in session:
        # Get user's email from session or API
        gmail_email = session.get('gmail_email', '')
        return render_template('emailer.html',
                           client_id=GOOGLE_CLIENT_ID,
                           gmail_email=gmail_email)
    else:
        return render_template('emailer.html',
                           client_id=GOOGLE_CLIENT_ID,
                           gmail_email='')

@app.route('/authorize')
def authorize():
    # Create flow instance to manage the OAuth 2.0 Authorization Grant Flow steps
    flow = Flow.from_client_secrets_file(
        CLIENT_SECRET_FILE,
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI
    )

    # Generate URL for request to Google's OAuth 2.0 server
    authorization_url, state = flow.authorization_url(
        access_type='offline',
        include_granted_scopes='true'
    )

    # Store the state in the session so the callback can verify it
    session['state'] = state

    return redirect(authorization_url)

@app.route('/callback')
def callback():
    # Handle the OAuth 2.0 server response
    state = session['state']
    
    flow = Flow.from_client_secrets_file(
        CLIENT_SECRET_FILE,
        scopes=SCOPES,
        state=state,
        redirect_uri=REDIRECT_URI
    )

    # Exchange authorization code for credentials
    flow.fetch_token(authorization_response=request.url)
    credentials = flow.credentials

    # Store credentials in session
    session['credentials'] = {
        'token': credentials.token,
        'refresh_token': credentials.refresh_token,
        'token_uri': credentials.token_uri,
        'client_id': credentials.client_id,
        'client_secret': credentials.client_secret,
        'scopes': credentials.scopes
    }

    # Get user's email address
    service = build('gmail', 'v1', credentials=credentials)
    profile = service.users().getProfile(userId='me').execute()
    session['gmail_email'] = profile['emailAddress']

    return redirect(url_for('index'))

@app.route('/send_email', methods=['POST'])
def send_email():
    if 'credentials' not in session:
        return redirect(url_for('authorize'))

    # Get credentials from session
    credentials_dict = session['credentials']
    credentials = Credentials(
        token=credentials_dict['token'],
        refresh_token=credentials_dict['refresh_token'],
        token_uri=credentials_dict['token_uri'],
        client_id=credentials_dict['client_id'],
        client_secret=credentials_dict['client_secret'],
        scopes=credentials_dict['scopes']
    )

    # Build Gmail service
    service = build('gmail', 'v1', credentials=credentials)

    try:
        # Get form data
        recipient = request.form['to']
        subject = request.form['subject']
        message_body = request.form['body']
        
        # Create message
        message = create_message(session['gmail_email'], recipient, subject, message_body)
        
        # Send message
        send_message(service, 'me', message)
        
        return "Email sent successfully!"
    except Exception as e:
        return f"An error occurred: {str(e)}"

def create_message(sender, to, subject, message_text):
    """Create a message for an email."""
    message = MIMEText(message_text)
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject
    return {'raw': base64.urlsafe_b64encode(message.as_bytes()).decode()}

def send_message(service, user_id, message):
    """Send an email message."""
    try:
        message = (service.users().messages().send(userId=user_id, body=message)
                   .execute())
        print(f"Message Id: {message['id']}")
        return message
    except Exception as e:
        print(f"An error occurred: {e}")
        raise

if __name__ == '__main__':
    # When running locally, disable OAuthlib's HTTPs verification
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
    
    # Specify a port if needed
    app.run(port=5000, debug=True)