import os
import base64
import mimetypes
import shutil
from flask import Flask, request, jsonify, render_template_string
from email.message import EmailMessage
import google.auth
from google.auth.exceptions import DefaultCredentialsError
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# App Setup
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Create Gmail Draft</title>
</head>
<body>
  <h1>Create Gmail Draft with File Attachment</h1>
  <form id="uploadForm" enctype="multipart/form-data">
    <input type="file" name="file" required />
    <button type="submit">Upload & Create Draft</button>
  </form>
  <p id="response"></p>

  <script>
    document.getElementById("uploadForm").addEventListener("submit", function (e) {
      e.preventDefault();
      const formData = new FormData();
      const fileInput = document.querySelector("input[name='file']");
      formData.append("file", fileInput.files[0]);

      fetch("/create-draft", {
        method: "POST",
        body: formData,
      })
      .then(response => response.json())
      .then(data => {
        document.getElementById("response").innerText = 
          data.status === "success"
            ? `✅ Draft created! ID: ${data.draft_id}`
            : `❌ Error: ${data.message}`;
      })
      .catch(error => {
        document.getElementById("response").innerText = `❌ Request failed: ${error}`;
      });
    });
  </script>
</body>
</html>
"""

@app.route("/", methods=["GET"])
def index():
    return render_template_string(HTML_TEMPLATE)


@app.route("/create-draft", methods=["POST"])
def create_draft():
    if "file" not in request.files:
        return jsonify({"status": "error", "message": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"status": "error", "message": "Empty file name"}), 400

    filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
    file.save(filepath)

    draft = gmail_create_draft_with_attachment(filepath)
    if draft:
        return jsonify({"status": "success", "draft_id": draft["id"]}), 200
    else:
        return jsonify({"status": "error", "message": "Failed to create draft"}), 500


def gmail_create_draft_with_attachment(attachment_filename):
    """Create and insert a draft email with attachment using Gmail API, with helpful error handling."""

    def gcloud_installed():
        return shutil.which("gcloud") is not None

    try:
        creds, _ = google.auth.default()
    except DefaultCredentialsError as e:
        print("\n❌ Google credentials not found.")
        if gcloud_installed():
            print("👉 Run the following command to authenticate:")
            print("   gcloud auth application-default login")
        else:
            print("⚠️ `gcloud` CLI not found.")
            print("➡️ Options:")
            print("   1. Install gcloud: https://cloud.google.com/sdk/docs/install")
            print("   2. Or set GOOGLE_APPLICATION_CREDENTIALS to your service account JSON key file.")
        print(f"\nDetails: {e}")
        return None

    try:
        service = build("gmail", "v1", credentials=creds)
        mime_message = EmailMessage()
        mime_message["To"] = "gduser1@workspacesamples.dev"  # Replace with actual recipient
        mime_message["From"] = "gduser2@workspacesamples.dev"  # Replace with authorized sender
        mime_message["Subject"] = "Sample with attachment"
        mime_message.set_content("Hi, this is automated mail with attachment. Please do not reply.")

        # MIME type detection
        type_subtype, _ = mimetypes.guess_type(attachment_filename)
        if not type_subtype:
            maintype, subtype = "application", "octet-stream"
        else:
            maintype, subtype = type_subtype.split("/")

        with open(attachment_filename, "rb") as fp:
            attachment_data = fp.read()
        mime_message.add_attachment(
            attachment_data, maintype, subtype, filename=os.path.basename(attachment_filename)
        )

        encoded_message = base64.urlsafe_b64encode(mime_message.as_bytes()).decode()
        create_draft_request_body = {"message": {"raw": encoded_message}}

        draft = service.users().drafts().create(userId="me", body=create_draft_request_body).execute()
        print(f'\n✅ Draft created!\n📧 Draft ID: {draft["id"]}')
        return draft

    except HttpError as error:
        print(f"\n❌ Gmail API error: {error}")
        return None


if __name__ == "__main__":
    app.run(debug=True)
