import os
import pickle
import base64
import mimetypes
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from flask import Flask, request, render_template_string
from werkzeug.utils import secure_filename

# Gmail API scope
SCOPES = ['https://www.googleapis.com/auth/gmail.send']

# Flask app setup
app = Flask(__name__)

# OAuth2 Authentication
def authenticate():
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    
    return creds

# Create Gmail message
def create_message(sender, to, subject, message_text, attachment=None):
    message = MIMEMultipart()
    message['to'] = to
    message['from'] = sender
    message['subject'] = subject
    message.attach(MIMEText(message_text, 'plain'))

    if attachment:
        content_type, encoding = mimetypes.guess_type(attachment)
        if content_type is None or encoding is not None:
            content_type = 'application/octet-stream'
        main_type, sub_type = content_type.split('/', 1)

        with open(attachment, 'rb') as file:
            file_data = file.read()
            msg_attachment = MIMEBase(main_type, sub_type)
            msg_attachment.set_payload(file_data)
            encoders.encode_base64(msg_attachment)
            msg_attachment.add_header('Content-Disposition', f'attachment; filename="{os.path.basename(attachment)}"')
            message.attach(msg_attachment)

    raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {'raw': raw_message}

# Send Gmail message
def send_message(service, sender, to, subject, message_text, attachment=None):
    message = create_message(sender, to, subject, message_text, attachment)
    try:
        result = service.users().messages().send(userId="me", body=message).execute()
        print(f'Message sent: {result["id"]}')
        return f'Email sent successfully! Message ID: {result["id"]}'
    except Exception as error:
        print(f'Error: {error}')
        return f'An error occurred: {error}'

# Flask route
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        sender = 'me'
        to = request.form['to']
        subject = request.form['subject']
        message_text = request.form['message']
        attachment = request.files.get('attachment')

        attachment_path = None
        if attachment and attachment.filename != '':
            filename = secure_filename(attachment.filename)
            attachment_path = os.path.join('uploads', filename)
            attachment.save(attachment_path)

        creds = authenticate()
        service = build('gmail', 'v1', credentials=creds)
        result_message = send_message(service, sender, to, subject, message_text, attachment_path)

        # Clean up uploaded file
        if attachment_path and os.path.exists(attachment_path):
            os.remove(attachment_path)

        return result_message

    return render_template_string("""
    <html>
        <head>
            <title>Send Email with Gmail API</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f7f6;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    width: 100%;
                    max-width: 600px;
                    margin: 50px auto;
                    padding: 20px;
                    background-color: #ffffff;
                    border-radius: 8px;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                }
                h2 {
                    text-align: center;
                    color: #4CAF50;
                }
                label {
                    font-weight: bold;
                    margin-bottom: 10px;
                    display: inline-block;
                }
                input[type="email"], input[type="text"], textarea, input[type="file"] {
                    width: 100%;
                    padding: 10px;
                    margin-bottom: 15px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    box-sizing: border-box;
                }
                button {
                    background-color: #4CAF50;
                    color: white;
                    padding: 12px 20px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    width: 100%;
                    font-size: 16px;
                }
                button:hover {
                    background-color: #45a049;
                }
                .form-group {
                    margin-bottom: 20px;
                }
                .hide{
                                  
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Send Email with Gmail API</h2>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="to">To:</label>
                        <input type="email" name="to" required>
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject:</label>
                        <input type="text" name="subject" required>
                    </div>
                    <div class="form-group">
                        <label for="message">Message:</label>
                        <textarea name="message" required>Hollo</textarea>
                    </div>
                    <div class="form-group">
                        <label for="html-text">HTML:</label>
                        <textarea  id="html-text" onchange="convertHTML2Base64(this)" name="html-text" required><h1>hello</h1></textarea>
                    </div>
                    <div class="form-group">
                        <label for="html">HTML:</label>
                        <textarea id="html" name="html" required><h1>hello</h1></textarea>
                    </div>
                                  
                    <div class="form-group hide">
                        <label for="attachment">Attachment (optional):</label>
                        <input type="file" name="attachment">
                    </div>
                    <button type="submit">Send Email</button>
                </form>
            </div>
        </body>
        <script>
             function convertHTML2Base64(e){
                             document.getElementById('html').innerHTML= btoa(e.value)
                                  }   
                                               
        </script>
    </html>
    """)

# Ensure upload folder exists
if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=True)
