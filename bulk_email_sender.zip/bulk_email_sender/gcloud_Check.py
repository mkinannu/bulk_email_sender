import subprocess
import shutil

def gmail_create_draft_with_attachment(attachment_filename):
    """Create and insert a draft email with attachment using Gmail API, with helpful error handling."""
    import base64
    import mimetypes
    from email.message import EmailMessage
    import google.auth
    from google.auth.exceptions import DefaultCredentialsError
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError

    def gcloud_installed():
        return shutil.which("gcloud") is not None

    try:
        creds, _ = google.auth.default()
    except DefaultCredentialsError as e:
        print("\n❌ Google credentials not found.")
        if gcloud_installed():
            print("👉 Run the following command to authenticate:")
            print("   gcloud auth application-default login")
        else:
            print("⚠️ It looks like `gcloud` CLI is not installed.")
            print("➡️ You can either:")
            print("   1. Install gcloud: https://cloud.google.com/sdk/docs/install")
            print("   2. Or set the GOOGLE_APPLICATION_CREDENTIALS environment variable")
            print("      to point to your service account key file (a .json file).")
        print(f"\nError details: {e}")
        return None

    try:
        service = build("gmail", "v1", credentials=creds)
        mime_message = EmailMessage()
        mime_message["To"] = "mdnannu04@gmail.com"
        mime_message["From"] = "oneprojectdev@gmail.com"
        mime_message["Subject"] = "sample with attachment"
        mime_message.set_content("Hi, this is automated mail with attachment. Please do not reply.")

        # MIME type detection
        type_subtype, _ = mimetypes.guess_type(attachment_filename)
        if not type_subtype:
            print(f"⚠️ Couldn't determine MIME type for {attachment_filename}. Using octet-stream.")
            maintype, subtype = "application", "octet-stream"
        else:
            maintype, subtype = type_subtype.split("/")

        with open(attachment_filename, "rb") as fp:
            attachment_data = fp.read()
        mime_message.add_attachment(
            attachment_data, maintype, subtype, filename=os.path.basename(attachment_filename)
        )

        encoded_message = base64.urlsafe_b64encode(mime_message.as_bytes()).decode()
        create_draft_request_body = {"message": {"raw": encoded_message}}

        draft = service.users().drafts().create(userId="me", body=create_draft_request_body).execute()
        print(f'\n✅ Draft created successfully!\n📧 Draft ID: {draft["id"]}')
        return draft

    except HttpError as error:
        print(f"\n❌ Gmail API error: {error}")
        return None
