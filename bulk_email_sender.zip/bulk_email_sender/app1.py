import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Email Configuration
smtp_server = 'Mail.envoytextiles.com'      # Replace with your SMTP server
smtp_port = 465                     # SSL port
smtp_user = 'hris@envoytextiles.com'  # Replace with your email
smtp_password = '@ETLHR@2025#' # Use App Password or real password (not recommended)

# Email Content
sender = smtp_user
receiver = 'mdnannu04@gmail.com'
subject = 'Test Email from Python'
body = 'Hello,\n\nThis is a test email sent from Python script using SMTP.\n\nRegards,\nPython Bot'

# Construct Email
message = MIMEMultipart()
message['From'] = sender
message['To'] = receiver
message['Subject'] = subject

message.attach(MIMEText(body, 'plain'))

# Send Email
try:
    with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
        server.login(smtp_user, smtp_password)
        server.sendmail(sender, receiver, message.as_string())
    print("✅ Email sent successfully.")
except Exception as e:
    print(f"❌ Failed to send email: {e}")
