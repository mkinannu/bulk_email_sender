# Gmail Sender App using Flask and Gmail API

This is a simple Flask-based web application that allows you to send emails using the **Gmail API**, including optional attachments.

## ✅ Features

- Send plain text or HTML emails
- Add attachments (PDF, JPG, etc.)
- OAuth 2.0 Google Sign-In flow
- Handles Gmail API authentication securely
- Console-based debugging messages for step-by-step tracking

---

## 📦 Requirements

- Python 3.8+
- A Google account
- A Google Cloud project with Gmail API enabled

---

## 🔧 Setup Instructions

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/gmail-sender-flask.git
cd gmail-sender-flask

for app.py install it first

pip install Flask google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client
pip install weasyprint
pip install Flask WeasyPrint
pip uninstall weasyprint cairocffi -y
pip install --upgrade pip setuptools wheel
pip install flask google-auth google-api-python-client
pip install pyppeteer
pip install xhtml2pdf requests
pip install playwright