# import os
# import base64
# import pickle
# from flask import Flask, redirect, url_for, session, request, render_template, flash
# from google_auth_oauthlib.flow import Flow
# from googleapiclient.discovery import build
# from google.auth.transport.requests import Request
# from google.oauth2.credentials import Credentials
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# from email.mime.base import MIMEBase
# import mimetypes

# app = Flask(__name__)
# app.secret_key = os.urandom(24)  # Random secret key for session

# # Configuration
# SCOPES = ['https://www.googleapis.com/auth/gmail.send']
# CLIENT_SECRETS_FILE = "credentials.json"
# TOKEN_FILE = "token.pickle"

# # For development only - remove in production!
# os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'


# def credentials_to_dict(credentials):
#     return {
#         'token': credentials.token,
#         'refresh_token': credentials.refresh_token,
#         'token_uri': credentials.token_uri,
#         'client_id': credentials.client_id,
#         'client_secret': credentials.client_secret,
#         'scopes': credentials.scopes
#     }


# def create_message_with_base64_attachment(sender, to, subject, message_text, base64_data, filename, mimetype=None):
#     """Create a message for an email with a base64 encoded attachment.

#     Args:
#         sender: Email address of the sender.
#         to: Email address of the receiver.
#         subject: The subject of the email message.
#         message_text: The text of the email message.
#         base64_data: The base64 encoded content of the attachment.
#         filename: The desired name of the attached file.
#         mimetype: The MIME type of the attachment (optional).

#     Returns:
#         An object containing the encoded email object.
#     """
#     message = MIMEMultipart()
#     message['to'] = to
#     message['from'] = sender
#     message['subject'] = subject

#     msg = MIMEText(message_text)
#     message.attach(msg)

#     if mimetype:
#         parts = mimetype.split('/')
#         if len(parts) == 2:
#             main_type, sub_type = parts
#             msg = MIMEBase(main_type, sub_type)
#         else:
#             msg = MIMEBase('application', 'octet-stream')  # Handle invalid mimetype
#     else:
#         msg = MIMEBase('application', 'octet-stream')
#     msg.set_payload(base64.b64decode(base64_data))
#     msg.add_header('Content-Disposition', 'attachment', filename=filename)
#     message.attach(msg)

#     message_bytes = message.as_bytes()  # Ensure it's bytes
#     raw = base64.urlsafe_b64encode(message_bytes).decode()
#     return {'raw': raw.decode()}



# @app.route('/')
# def index():
#     if 'credentials' not in session:
#         return redirect(url_for('authorize'))
#     return render_template('form.html')


# @app.route('/authorize')
# def authorize():
#     flow = Flow.from_client_secrets_file(
#         CLIENT_SECRETS_FILE,
#         scopes=SCOPES,
#         redirect_uri=url_for('oauth2callback', _external=True)
#     )
#     authorization_url, state = flow.authorization_url(
#         access_type='offline',
#         prompt='consent'
#     )
#     session['state'] = state
#     return redirect(authorization_url)


# @app.route('/oauth2callback')
# def oauth2callback():
#     state = session['state']
#     flow = Flow.from_client_secrets_file(
#         CLIENT_SECRETS_FILE,
#         scopes=SCOPES,
#         state=state,
#         redirect_uri=url_for('oauth2callback', _external=True)
#     )

#     flow.fetch_token(authorization_response=request.url)
#     credentials = flow.credentials

#     # Save credentials to session
#     session['credentials'] = credentials_to_dict(credentials)

#     # Save credentials to file
#     with open(TOKEN_FILE, 'wb') as token:
#         pickle.dump(credentials, token)

#     return redirect(url_for('index'))


# @app.route('/send', methods=['POST'])
# def send():
#     if 'credentials' not in session:
#         return redirect(url_for('authorize'))

#     try:
#         # Load credentials from session
#         creds_dict = session['credentials']
#         creds = Credentials(
#             token=creds_dict['token'],
#             refresh_token=creds_dict['refresh_token'],
#             token_uri=creds_dict['token_uri'],
#             client_id=creds_dict['client_secret'],
#             scopes=creds_dict['scopes']
#         )

#         # Refresh token if expired
#         if creds.expired and creds.refresh_token:
#             creds.refresh(Request())
#             session['credentials'] = credentials_to_dict(creds)
#             with open(TOKEN_FILE, 'wb') as token:
#                 pickle.dump(creds, token)

#         # Build service
#         service = build('gmail', 'v1', credentials=creds)

#         # Get form data
#         to = request.form['to']
#         subject = request.form['subject']
#         message_text = request.form['message']
#         base64_txt = request.form['attach']
#         filename = request.form['filename']  # Get filename
#         mimetype = request.form['mimetype'] #get mimetype

#         #try:
#         #    base64.b64decode(base64_txt)
#         #except Exception as e:
#         #    flash(f"Invalid base64 data: {e}", "danger")
#         #    return redirect(url_for('index'))

#         if not filename:
#             flash("Filename is required", "danger")
#             return redirect(url_for('index'))

#         # Create and send message
#         message = create_message_with_base64_attachment("me", to, subject, message_text, base64_txt, filename, mimetype)
#         service.users().messages().send(userId="me", body=message).execute()

#         flash('Email sent successfully!', 'success')
#     except Exception as e:
#         flash(f'An error occurred: {str(e)}', 'danger')

#     return redirect(url_for('index'))


# if __name__ == '__main__':
#     app.run(ssl_context='adhoc', debug=True)import base64
import mimetypes
import os
from email.message import EmailMessage
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.text import MIMEText

import google.auth
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


def gmail_create_draft_with_attachment():
  """Create and insert a draft email with attachment.
   Print the returned draft's message and id.
  Returns: Draft object, including draft id and message meta data.

  Load pre-authorized user credentials from the environment.
  TODO(developer) - See https://developers.google.com/identity
  for guides on implementing OAuth2 for the application.
  """
  creds, _ = google.auth.default()

  try:
    # create gmail api client
    service = build("gmail", "v1", credentials=creds)
    mime_message = EmailMessage()

    # headers
    mime_message["To"] = "mdnannu04@gmail,com"
    mime_message["From"] = "oneprojectdev@gmail.com"
    mime_message["Subject"] = "sample with attachment"

    # text
    mime_message.set_content(
        "Hi, this is automated mail with attachment.Please do not reply."
    )

    # attachment
    attachment_filename = "photo.jpg"
    # guessing the MIME type
    type_subtype, _ = mimetypes.guess_type(attachment_filename)
    maintype, subtype = type_subtype.split("/")

    with open(attachment_filename, "rb") as fp:
      attachment_data = fp.read()
    mime_message.add_attachment(attachment_data, maintype, subtype)

    encoded_message = base64.urlsafe_b64encode(mime_message.as_bytes()).decode()

    create_draft_request_body = {"message": {"raw": encoded_message}}
    # pylint: disable=E1101
    draft = (
        service.users()
        .drafts()
        .create(userId="me", body=create_draft_request_body)
        .execute()
    )
    print(f'Draft id: {draft["id"]}\nDraft message: {draft["message"]}')
  except HttpError as error:
    print(f"An error occurred: {error}")
    draft = None
  return draft


def build_file_part(file):
  """Creates a MIME part for a file.

  Args:
    file: The path to the file to be attached.

  Returns:
    A MIME part that can be attached to a message.
  """
  content_type, encoding = mimetypes.guess_type(file)

  if content_type is None or encoding is not None:
    content_type = "application/octet-stream"
  main_type, sub_type = content_type.split("/", 1)
  if main_type == "text":
    with open(file, "rb"):
      msg = MIMEText("r", _subtype=sub_type)
  elif main_type == "image":
    with open(file, "rb"):
      msg = MIMEImage("r", _subtype=sub_type)
  elif main_type == "audio":
    with open(file, "rb"):
      msg = MIMEAudio("r", _subtype=sub_type)
  else:
    with open(file, "rb"):
      msg = MIMEBase(main_type, sub_type)
      msg.set_payload(file.read())
  filename = os.path.basename(file)
  msg.add_header("Content-Disposition", "attachment", filename=filename)
  return msg


if __name__ == "__main__":
  gmail_create_draft_with_attachment()